-- Run this entire file in Supabase Dashboard > SQL Editor.
-- Private student data: every row is owned by the authenticated user.
create extension if not exists pgcrypto;

create table if not exists public.student_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('tasks', 'plans', 'notes')),
  title text not null check (char_length(title) between 1 and 120),
  detail text not null default '' check (char_length(detail) <= 5000),
  color text not null default 'blue' check (color in ('blue','purple','mint','gold','green')),
  done boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists student_items_user_created_idx
  on public.student_items (user_id, created_at desc);

alter table public.student_items enable row level security;
alter table public.student_items force row level security;

-- Explicitly scope all reads and writes to the signed-in user's UUID.
drop policy if exists "Students can read their own items" on public.student_items;
create policy "Students can read their own items"
  on public.student_items for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Students can insert their own items" on public.student_items;
create policy "Students can insert their own items"
  on public.student_items for insert to authenticated
  with check ((select auth.uid()) = user_id);

drop policy if exists "Students can update their own items" on public.student_items;
create policy "Students can update their own items"
  on public.student_items for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Students can delete their own items" on public.student_items;
create policy "Students can delete their own items"
  on public.student_items for delete to authenticated
  using ((select auth.uid()) = user_id);

-- No public/anonymous policies are created. Never put a Supabase service-role key in client code.
