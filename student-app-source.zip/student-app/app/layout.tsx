import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Student App — Plan • Study • Achieve', description: 'Your studies, your plan, all in one place.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
