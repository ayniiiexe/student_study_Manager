# Student App — full source code

A dark, cinematic student dashboard inspired by the supplied mockup. Built with Next.js App Router, TypeScript, Supabase Auth, Supabase Postgres and Row Level Security (RLS).

## Included

- Email/password sign-up and sign-in (required email and password fields; minimum 8 characters on sign-up)
- Email confirmation supported by Supabase Auth settings
- Authenticator-app TOTP two-factor authentication enrollment and verification UI
- Student dashboard, tasks, study plans, notes, subjects, calendar layout, profile/security settings
- Persistent database storage for notes/tasks/plans
- Per-user database isolation using PostgreSQL Row Level Security policies
- Responsive layout for desktop and mobile
- No service-role key in browser code

## Important security note

This is a complete starter implementation, but it is **not yet a production-certified or fully tested live service**. The MFA setup is available from Security settings. Supabase Auth MFA enrollment alone does not automatically require MFA for every login. If you want to make MFA mandatory for all accounts, configure Supabase Authentication's minimum AAL policy and add an AAL2 gate/step-up flow before permitting access to sensitive pages. Test recovery, email confirmation, password reset, rate limits, and MFA-required sessions before inviting real users. Never collect/store passwords yourself; Supabase Auth handles them.

## Prerequisites

- Node.js 20.9 or newer
- A Supabase account/project
- A Vercel account (for hosting)

## 1. Configure Supabase

1. Create a project in Supabase.
2. Open **SQL Editor**, create a new query, paste the complete contents of `supabase/schema.sql`, and run it.
3. Open **Project Settings → API** (or API Keys). Copy the Project URL and the publishable/anon key.
4. In **Authentication → URL Configuration**, set your local site URL to `http://localhost:3000`. Add your eventual Vercel URL to allowed redirect URLs.
5. In **Authentication → Providers**, enable Email. For safer real use, keep email confirmation enabled and configure SMTP so confirmation messages reliably reach users.
6. Check **Authentication → Multi-Factor Authentication** and enable TOTP factors.

## 2. Run locally

```bash
npm install
cp .env.example .env.local
```

Edit `.env.local` and fill in the Supabase Project URL and publishable/anon key. These two values are intended for client initialization; database access is still protected by RLS. Do not put service-role or secret keys in `NEXT_PUBLIC_*` variables.

```bash
npm run dev
```

Open `http://localhost:3000`.

## 3. Deploy to Vercel

1. Push this project folder to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` under Project Settings → Environment Variables for Preview and Production.
4. Deploy. After deployment, add the production URL to Supabase Authentication's allowed redirect URLs and set the production site URL.
5. Test a new account, email confirmation, sign-out/sign-in, creating and deleting a note, cross-account isolation (two separate test users), and 2FA enrollment.

## 4. Recommended launch hardening

- Enforce MFA via Supabase's Authenticator Assurance Level (AAL) policy if it must be mandatory, and test the login step-up flow.
- Configure SMTP, password recovery, rate limits, and abuse protection in Supabase.
- Add a privacy policy and terms appropriate to the actual deployment and data collected.
- Consider a server-side auth/middleware layer and automated tests before production use.
- Review database policies whenever new tables or features are added.

## Source structure

```text
student-app/
├── app/
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   └── StudentApp.tsx
├── lib/
│   └── supabase.ts
├── supabase/
│   └── schema.sql
├── .env.example
├── .gitignore
├── next.config.ts
├── package.json
└── tsconfig.json
```

## Customise the subjects

Edit the `subjectsSeed` array near the top of `components/StudentApp.tsx`. The included subjects are sample content and are not automatically written to the database.
